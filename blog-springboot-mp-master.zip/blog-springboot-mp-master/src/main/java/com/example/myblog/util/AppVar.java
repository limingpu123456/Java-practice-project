package com.example.myblog.util;

/**
 * 全局的公共变量
 */
public class AppVar {
    // 存储用户的 session key
    public static final String SESSION_KEY_USERINFO = "SESSION_KEY_USERINFO";
}
